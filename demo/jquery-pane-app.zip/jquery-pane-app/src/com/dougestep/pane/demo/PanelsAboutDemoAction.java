package com.dougestep.pane.demo;

import net.sourceforge.stripes.action.ActionBean;
import net.sourceforge.stripes.action.ActionBeanContext;
import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.action.UrlBinding;

@UrlBinding("/jquery-pane-demo")
public class PanelsAboutDemoAction implements ActionBean {
	private static final String VIEW = "/WEB-INF/jsp/about.jsp";
	private ActionBeanContext actionBeanContext;

	@Override
	public ActionBeanContext getContext() {
		return actionBeanContext;
	}

	@Override
	public void setContext(ActionBeanContext actionBeanContext) {
		this.actionBeanContext = actionBeanContext;
	}

	@DefaultHandler
	public Resolution view() {
		return new ForwardResolution(VIEW);
	}
}
