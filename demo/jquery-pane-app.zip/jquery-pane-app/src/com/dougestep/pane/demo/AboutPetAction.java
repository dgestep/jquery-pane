package com.dougestep.pane.demo;

import java.util.List;

import net.sourceforge.stripes.action.ActionBean;
import net.sourceforge.stripes.action.ActionBeanContext;
import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.Message;
import net.sourceforge.stripes.action.RedirectResolution;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.action.SimpleMessage;
import net.sourceforge.stripes.action.UrlBinding;
import net.sourceforge.stripes.validation.SimpleError;
import net.sourceforge.stripes.validation.ValidationError;
import net.sourceforge.stripes.validation.ValidationErrors;

@UrlBinding("/about-pet")
public class AboutPetAction implements ActionBean {
	private static final String VIEW = "/WEB-INF/jsp/about-pet.jsp";
	private ActionBeanContext actionBeanContext;
	private String name;
	private String age;
	private String status;
	private List<String> petType;

	@Override
	public ActionBeanContext getContext() {
		return actionBeanContext;
	}

	@Override
	public void setContext(ActionBeanContext actionBeanContext) {
		this.actionBeanContext = actionBeanContext;
	}

	@DefaultHandler
	public Resolution view() {
		if (status == null) {
			setStatus("Alive");
		}
		return new ForwardResolution(VIEW);
	}
	
	public Resolution save() {
		ActionBeanContext ctx = getContext();
		List<Message> messages = ctx.getMessages();
		SimpleMessage message = new SimpleMessage("Woohoo!");
		messages.add(message);
		
		RedirectResolution r = new RedirectResolution(this.getClass());
		r.addParameter("name", name);
		r.addParameter("age", age);
		r.addParameter("status", status);
		r.addParameter("petType", petType);
		return r;
	}
	
	public Resolution saveWithError() {
		ValidationError globalError = new SimpleError("Please correct the error");
		ValidationError fieldError = new SimpleError("");
		
		ActionBeanContext ctx = getContext();
		ValidationErrors errors = ctx.getValidationErrors();
		errors.add("name", fieldError);
		errors.addGlobalError(globalError);
		
		return view();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public List<String> getPetType() {
		return petType;
	}
	
	public void setPetType(List<String> petType) {
		this.petType = petType;
	}
}
