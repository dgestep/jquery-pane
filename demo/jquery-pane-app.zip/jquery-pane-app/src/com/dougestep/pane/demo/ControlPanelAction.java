package com.dougestep.pane.demo;

import java.util.ArrayList;
import java.util.List;

import net.sourceforge.stripes.action.ActionBean;
import net.sourceforge.stripes.action.ActionBeanContext;
import net.sourceforge.stripes.action.DefaultHandler;
import net.sourceforge.stripes.action.ForwardResolution;
import net.sourceforge.stripes.action.Resolution;
import net.sourceforge.stripes.action.UrlBinding;

@UrlBinding("/control-panel")
public class ControlPanelAction implements ActionBean {
	private static final String VIEW = "/WEB-INF/jsp/control-panel.jsp";
	private ActionBeanContext actionBeanContext;

	@Override
	public ActionBeanContext getContext() {
		return actionBeanContext;
	}

	@Override
	public void setContext(ActionBeanContext actionBeanContext) {
		this.actionBeanContext = actionBeanContext;
	}

	@DefaultHandler
	public Resolution view() {
		return new ForwardResolution(VIEW);
	}
	
	public List<String> getPaneIds() {
		List<String> l = new ArrayList<String>();
		l.add("welcome-message");
		l.add("pane-controls");
		l.add("about-you");
		l.add("about-pet");
		
		return l;
	}
}
